<?php $__env->startSection('content'); ?>
    <section id="basic-horizontal-layouts">
        <div class="row match-height">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add option to <?php echo e(\App\Service::findOrFail($_GET['service_id'])->name); ?></h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-horizontal" action="<?php echo e(route('admin.service_options.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-body">
                                    <div class="row">
                                        <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <div class="form-group row">
                                                <div class="col-md-4">
                                                    <span>Title <?php echo e($locale); ?></span>
                                                </div>
                                                <div class="col-md-8">
                                                    <input required type="text" class="form-control" name="title[<?php echo e($locale); ?>]" placeholder="Title <?php echo e($locale); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="service_id" value="<?php echo e((isset($_GET['service_id']))?$_GET['service_id']:0); ?>">
                                        <div class="col-md-8 offset-md-4">
                                            <button type="submit" class="btn btn-primary mr-1 mb-1">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/farag/Desktop/projects/Muyawama/resources/views/admin/service_options/create.blade.php ENDPATH**/ ?>