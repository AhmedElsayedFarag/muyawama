<?php $__env->startSection('content'); ?>
    <section id="basic-horizontal-layouts">
        <div class="row match-height">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit <?php echo e($service->name); ?></h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-horizontal" action="<?php echo e(route('admin.services.update',$service->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(method_field('PUT')); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="form-body">
                                    <div class="row">
                                        <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <div class="form-group row">
                                                <div class="col-md-4">
                                                    <span>Name <?php echo e($locale); ?></span>
                                                </div>
                                                <div class="col-md-8">
                                                    <input required type="text" class="form-control" name="name[<?php echo e($locale); ?>]" value="<?php echo e($service->translate($locale)->name); ?>" placeholder="name <?php echo e($locale); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <div class="form-group row">
                                                <div class="col-md-4">
                                                    <span>image</span>
                                                </div>
                                                <div class="col-md-8">
                                                    <img class="img-fluid img-thumbnail img-lg" src="<?php echo e(asset($service->image)); ?>">
                                                    <strong class="text-danger">if you do not want to change image leave it blank</strong>
                                                    <input type="file"  class="form-control" name="image">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-8 offset-md-4">
                                            <button type="submit" class="btn btn-primary mr-1 mb-1">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/farag/Desktop/projects/Muyawama/resources/views/admin/services/edit.blade.php ENDPATH**/ ?>