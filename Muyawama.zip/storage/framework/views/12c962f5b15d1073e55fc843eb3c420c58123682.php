<?php $__env->startSection('content'); ?>
    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e((isset($_GET['parent_id']))?\App\Service::findOrFail($_GET['parent_id'])->name:'Services'); ?></h4>
                        <?php if(!isset($_GET['parent_id'])): ?>
                        <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary pull-right"><i class="feather icon-plus-square"></i> Add</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">

                            <div class="table-responsive">
                                <table class="table zero-configuration">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Options</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($service->name); ?></td>
                                            <td><img class="img-fluid img-thumbnail img-sm" src="<?php echo e(asset($service->image)); ?>"> </td>
                                            <td>
                                                <?php if(!$service->parent_id): ?>
                                                <a href="<?php echo e(route('admin.services.create',['parent_id'=>$service->id])); ?>" class="btn btn-primary"><i class="feather icon-plus-square"></i> Add sub</a>
                                                <a href="<?php echo e(route('admin.services.index',['parent_id'=>$service->id])); ?>" class="btn btn-primary"><i class="feather icon-eye"></i> View sub</a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('admin.service_options.create',['service_id'=>$service->id])); ?>" class="btn btn-primary"><i class="feather icon-plus-square"></i> Add options</a>
                                                    <a href="<?php echo e(route('admin.service_options.index',['service_id'=>$service->id])); ?>" class="btn btn-primary"><i class="feather icon-plus-square"></i> View options</a>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('admin.services.edit',$service->id)); ?>" class="btn btn-info"><i class="feather icon-edit"></i> Edit</a>
                                                <a onclick="fireDeleteEvent(<?php echo e($service->id); ?>)" type="button" class="btn btn-danger"><i class="feather icon-trash"></i> Delete</a>
                                                <form action="<?php echo e(route('admin.services.destroy',$service->id)); ?>" method="POST" id="form-<?php echo e($service->id); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                </form>


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Options</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/farag/Desktop/projects/Muyawama/resources/views/admin/services/index.blade.php ENDPATH**/ ?>