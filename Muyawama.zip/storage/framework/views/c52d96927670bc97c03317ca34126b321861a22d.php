<?php $__env->startSection('content'); ?>
    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e((isset($_GET['service_id']))?\App\Service::findOrFail($_GET['service_id'])->name:'Services'); ?></h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">

                            <div class="table-responsive">
                                <table class="table zero-configuration">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>title</th>
                                        <th>Options</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($service->title); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.service_options.edit',$service->id)); ?>" class="btn btn-info"><i class="feather icon-edit"></i> Edit</a>
                                                <a onclick="fireDeleteEvent(<?php echo e($service->id); ?>)" type="button" class="btn btn-danger"><i class="feather icon-trash"></i> Delete</a>
                                                <form action="<?php echo e(route('admin.service_options.destroy',$service->id)); ?>" method="POST" id="form-<?php echo e($service->id); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                </form>


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>title</th>
                                        <th>Options</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/farag/Desktop/projects/Muyawama/resources/views/admin/service_options/index.blade.php ENDPATH**/ ?>